# Benchmark front

Each workload cohort has one scale per view across architectures. Dominance is per architecture within a matched revision, client count and duration.
Cold install age is a shared reference in the evidence table, not a swept-config ranking. The readiness plot uses warm rollout duration only. Missing or invalid axes are not plotted. These are individual observations, not confidence intervals.

## Cohort: clients=50, duration=1200 s, revision=83c1262b9059de6fa512f357eff87d16f9adf93d, protocol=synthetic-postgis-v1, warmup=300 s, self-SA=5 s

### amd64

#### footprint vs throughput

Front: baseline-r1, postgis-buffers-r1
Dominated: baseline-r2, baseline-r3, postgis-buffers-r2, postgis-buffers-r3, postgis-wal-r1, postgis-wal-r2, postgis-wal-r3

#### footprint vs mean latency

Front: baseline-r1, postgis-buffers-r1, postgis-buffers-r2, postgis-wal-r3
Dominated: baseline-r2, baseline-r3, postgis-buffers-r3, postgis-wal-r1, postgis-wal-r2

#### footprint vs warm rollout time

Front: postgis-buffers-r1, postgis-wal-r2, postgis-wal-r3
Dominated: baseline-r1, baseline-r2, baseline-r3, postgis-buffers-r2, postgis-buffers-r3, postgis-wal-r1

### arm64

#### footprint vs throughput

Front: baseline-r1, postgis-buffers-r1, postgis-buffers-r3
Dominated: baseline-r2, baseline-r3, postgis-buffers-r2, postgis-wal-r1, postgis-wal-r2, postgis-wal-r3

#### footprint vs mean latency

Front: postgis-buffers-r1, postgis-buffers-r2
Dominated: baseline-r1, baseline-r2, baseline-r3, postgis-buffers-r3, postgis-wal-r1, postgis-wal-r2, postgis-wal-r3

#### footprint vs warm rollout time

Front: postgis-buffers-r1, postgis-wal-r2
Dominated: baseline-r1, baseline-r2, baseline-r3, postgis-buffers-r2, postgis-buffers-r3, postgis-wal-r1, postgis-wal-r3

### Counterbalanced PostgreSQL session repeats

Each native runner retains one database and shared data/filesystem-cache history. Every session resets the five GUCs and restarts PostgreSQL, then warms 50 live clients for at least 300 s before 1200 s measured. Cyclic configuration order balances ordinal position, not all carryover effects. These are session repeats, not independent installs, causal tuning effects or an ISA ranking. Incomplete or identity-invalid nine-session architecture blocks cannot enter the front.

| Architecture | Configuration | Valid repeats / planned | Received messages/s median [range] | Mean ping-pong ms median [range] |
| --- | --- | --- | --- | --- |
| amd64 | baseline | 3 / 3 | 494.977 [494.968, 495.494] | 445.814 [436.416, 468.674] |
| amd64 | postgis-buffers | 3 / 3 | 495.329 [495.095, 495.443] | 444.004 [435.540, 454.316] |
| amd64 | postgis-wal | 3 / 3 | 495.244 [495.178, 495.262] | 438.340 [432.944, 438.462] |
| arm64 | baseline | 3 / 3 | 495.427 [495.421, 495.596] | 474.632 [470.507, 476.548] |
| arm64 | postgis-buffers | 3 / 3 | 495.427 [495.136, 495.791] | 463.528 [457.217, 475.913] |
| arm64 | postgis-wal | 3 / 3 | 495.287 [495.284, 495.398] | 464.159 [457.785, 470.235] |

### Observed load and footprint

| Architecture | Config | Steady working set (MiB) | Peak working set (MiB) | Steady CPU (m) | Received messages/s | Mean ping-pong (ms) | Cold install reference (s) | Warm rollout (s) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| amd64 | baseline-r1 | 3932.426 | 3940.961 | 166.316 | 495.494 | 436.416 | 150.000 | 21.014 |
| amd64 | baseline-r2 | 4019.883 | 4022.836 | 145.068 | 494.968 | 445.814 | 150.000 | 12.077 |
| amd64 | baseline-r3 | 4051.246 | 4053.676 | 145.956 | 494.977 | 468.674 | 150.000 | 12.031 |
| amd64 | postgis-buffers-r1 | 3917.879 | 3956.641 | 142.083 | 495.095 | 454.316 | 150.000 | 12.021 |
| amd64 | postgis-buffers-r2 | 3993.824 | 4019.863 | 140.091 | 495.443 | 435.540 | 150.000 | 21.507 |
| amd64 | postgis-buffers-r3 | 4059.340 | 4062.633 | 150.977 | 495.329 | 444.004 | 150.000 | 11.848 |
| amd64 | postgis-wal-r1 | 3964.309 | 3964.309 | 232.442 | 495.244 | 438.462 | 150.000 | 12.208 |
| amd64 | postgis-wal-r2 | 4011.461 | 4035.484 | 133.854 | 495.262 | 438.340 | 150.000 | 11.784 |
| amd64 | postgis-wal-r3 | 4038.781 | 4041.707 | 137.925 | 495.178 | 432.944 | 150.000 | 11.481 |
| arm64 | baseline-r1 | 3888.719 | 3892.145 | 133.906 | 495.596 | 476.548 | 131.000 | 21.359 |
| arm64 | baseline-r2 | 3973.102 | 3973.102 | 125.515 | 495.421 | 474.632 | 131.000 | 21.527 |
| arm64 | baseline-r3 | 3985.152 | 3987.832 | 134.456 | 495.427 | 470.507 | 131.000 | 11.945 |
| arm64 | postgis-buffers-r1 | 3880.570 | 3892.816 | 135.054 | 495.427 | 463.528 | 131.000 | 11.499 |
| arm64 | postgis-buffers-r2 | 3942.047 | 3944.961 | 135.043 | 495.136 | 457.217 | 131.000 | 21.930 |
| arm64 | postgis-buffers-r3 | 3996.008 | 3999.582 | 114.052 | 495.791 | 475.913 | 131.000 | 11.957 |
| arm64 | postgis-wal-r1 | 3914.445 | 3914.445 | 201.555 | 495.284 | 464.159 | 131.000 | 12.274 |
| arm64 | postgis-wal-r2 | 3954.406 | 3980.035 | 148.518 | 495.398 | 457.785 | 131.000 | 11.474 |
| arm64 | postgis-wal-r3 | 3975.566 | 3975.816 | 126.503 | 495.287 | 470.235 | 131.000 | 11.576 |

### Observed pod startup phases

These are the pods observed at each config's collection time. A database-only rollout can reuse an earlier TAK pod; these rows are not proof that each config independently measured both a cold and a warm TAK start. Container start includes entrypoint work and does not measure JVM start or class loading. Legacy jvm_to_log_s values also used container timestamps. Negative timings are invalid observations, not durations.

| Architecture | Config | App | Image pull (s) | Init containers (s) | Container start to first startup log (s) | Startup log to Ready (s) |
| --- | --- | --- | --- | --- | --- | --- |
| amd64 | baseline-r1 | takserver-messaging | 0.000 | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | baseline-r1 | takserver-api | 0.000 | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | baseline-r2 | takserver-messaging | not measured | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | baseline-r2 | takserver-api | not measured | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | baseline-r3 | takserver-messaging | not measured | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | baseline-r3 | takserver-api | not measured | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | postgis-buffers-r1 | takserver-messaging | 0.000 | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | postgis-buffers-r1 | takserver-api | 0.000 | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | postgis-buffers-r2 | takserver-messaging | not measured | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | postgis-buffers-r2 | takserver-api | not measured | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | postgis-buffers-r3 | takserver-messaging | not measured | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | postgis-buffers-r3 | takserver-api | not measured | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | postgis-wal-r1 | takserver-messaging | 0.000 | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | postgis-wal-r1 | takserver-api | 0.000 | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | postgis-wal-r2 | takserver-messaging | not measured | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | postgis-wal-r2 | takserver-api | not measured | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| amd64 | postgis-wal-r3 | takserver-messaging | not measured | wait-deps: 32.000; import-trust: 43.000; render-oidc: 0.000 | 59.439 | 5.561 |
| amd64 | postgis-wal-r3 | takserver-api | not measured | wait-deps: 32.000; import-trust: 42.000; render-oidc: 0.000 | 70.298 | 3.702 |
| arm64 | baseline-r1 | takserver-messaging | 0.000 | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | baseline-r1 | takserver-api | 0.000 | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | baseline-r2 | takserver-messaging | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | baseline-r2 | takserver-api | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | baseline-r3 | takserver-messaging | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | baseline-r3 | takserver-api | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | postgis-buffers-r1 | takserver-messaging | 0.000 | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | postgis-buffers-r1 | takserver-api | 0.000 | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | postgis-buffers-r2 | takserver-messaging | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | postgis-buffers-r2 | takserver-api | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | postgis-buffers-r3 | takserver-messaging | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | postgis-buffers-r3 | takserver-api | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | postgis-wal-r1 | takserver-messaging | 0.000 | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | postgis-wal-r1 | takserver-api | 0.000 | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | postgis-wal-r2 | takserver-messaging | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | postgis-wal-r2 | takserver-api | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |
| arm64 | postgis-wal-r3 | takserver-messaging | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 40.311 | 0.689 |
| arm64 | postgis-wal-r3 | takserver-api | not measured | wait-deps: 37.000; import-trust: 39.000; render-oidc: 0.000 | 47.656 | 3.344 |

### Postgres

Memory is sampled container working set, not process RSS. Database counters describe cot; checkpoints and backend writes are cluster-wide. A counter-reset error in the record caveats means the counters are not verified for this load window.

#### Load, cache and memory

| Architecture | Config | Hit ratio | Temp files | Temp bytes | Steady working set (MiB) | Peak working set (MiB) | Received messages/s | Mean ping-pong (ms) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| amd64 | baseline-r1 | 0.999985 | 0.000 | 0.000 | 54.562 | 54.562 | 495.494 | 436.416 |
| amd64 | baseline-r2 | 0.985791 | 0.000 | 0.000 | 62.926 | 62.926 | 494.968 | 445.814 |
| amd64 | baseline-r3 | 0.979927 | 0.000 | 0.000 | 61.246 | 61.395 | 494.977 | 468.674 |
| amd64 | postgis-buffers-r1 | 0.997729 | 0.000 | 0.000 | 61.617 | 92.242 | 495.095 | 454.316 |
| amd64 | postgis-buffers-r2 | 0.982736 | 0.000 | 0.000 | 60.684 | 90.156 | 495.443 | 435.540 |
| amd64 | postgis-buffers-r3 | 0.977842 | 0.000 | 0.000 | 62.203 | 62.203 | 495.329 | 444.004 |
| amd64 | postgis-wal-r1 | 0.986558 | 0.000 | 0.000 | 59.605 | 59.605 | 495.244 | 438.462 |
| amd64 | postgis-wal-r2 | 0.988843 | 0.000 | 0.000 | 59.156 | 85.863 | 495.262 | 438.340 |
| amd64 | postgis-wal-r3 | 0.983491 | 0.000 | 0.000 | 60.316 | 60.316 | 495.178 | 432.944 |
| arm64 | baseline-r1 | 0.999994 | 0.000 | 0.000 | 55.789 | 63.770 | 495.596 | 476.548 |
| arm64 | baseline-r2 | 0.985775 | 0.000 | 0.000 | 63.301 | 63.695 | 495.421 | 474.632 |
| arm64 | baseline-r3 | 0.979917 | 0.000 | 0.000 | 61.250 | 61.250 | 495.427 | 470.507 |
| arm64 | postgis-buffers-r1 | 0.997652 | 0.000 | 0.000 | 62.465 | 62.465 | 495.427 | 463.528 |
| arm64 | postgis-buffers-r2 | 0.982694 | 0.000 | 0.000 | 58.449 | 58.449 | 495.136 | 457.217 |
| arm64 | postgis-buffers-r3 | 0.977810 | 0.000 | 0.000 | 61.984 | 61.984 | 495.791 | 475.913 |
| arm64 | postgis-wal-r1 | 0.986540 | 0.000 | 0.000 | 57.445 | 79.723 | 495.284 | 464.159 |
| arm64 | postgis-wal-r2 | 0.988811 | 0.000 | 0.000 | 56.652 | 82.652 | 495.398 | 457.785 |
| arm64 | postgis-wal-r3 | 0.983473 | 0.000 | 0.000 | 58.781 | 58.781 | 495.287 | 470.235 |

#### Checkpoints and backend writes

| Architecture | Config | Timed checkpoints | Requested checkpoints | Checkpoint write (ms) | Checkpoint sync (ms) | Backend write operations |
| --- | --- | --- | --- | --- | --- | --- |
| amd64 | baseline-r1 | 4.000 | 0.000 | 235700.000 | 16.000 | 11903.000 |
| amd64 | baseline-r2 | 4.000 | 0.000 | 488128.000 | 15.000 | 11910.000 |
| amd64 | baseline-r3 | 4.000 | 0.000 | 490984.000 | 16.000 | 11909.000 |
| amd64 | postgis-buffers-r1 | 4.000 | 0.000 | 293111.000 | 17.000 | 11918.000 |
| amd64 | postgis-buffers-r2 | 4.000 | 0.000 | 307535.000 | 9.000 | 11909.000 |
| amd64 | postgis-buffers-r3 | 4.000 | 0.000 | 511568.000 | 17.000 | 11905.000 |
| amd64 | postgis-wal-r1 | 1.000 | 0.000 | 152057.000 | 3.000 | 11922.000 |
| amd64 | postgis-wal-r2 | 1.000 | 0.000 | 192021.000 | 4.000 | 11917.000 |
| amd64 | postgis-wal-r3 | 1.000 | 0.000 | 187824.000 | 4.000 | 11901.000 |
| arm64 | baseline-r1 | 4.000 | 0.000 | 232801.000 | 33.000 | 11911.000 |
| arm64 | baseline-r2 | 4.000 | 0.000 | 479612.000 | 29.000 | 11915.000 |
| arm64 | baseline-r3 | 4.000 | 0.000 | 502295.000 | 29.000 | 11902.000 |
| arm64 | postgis-buffers-r1 | 4.000 | 0.000 | 294014.000 | 34.000 | 11909.000 |
| arm64 | postgis-buffers-r2 | 4.000 | 0.000 | 303535.000 | 22.000 | 11904.000 |
| arm64 | postgis-buffers-r3 | 4.000 | 0.000 | 518185.000 | 29.000 | 11913.000 |
| arm64 | postgis-wal-r1 | 1.000 | 0.000 | 150257.000 | 8.000 | 11919.000 |
| arm64 | postgis-wal-r2 | 1.000 | 0.000 | 194818.000 | 8.000 | 11908.000 |
| arm64 | postgis-wal-r3 | 1.000 | 0.000 | 189812.000 | 7.000 | 11898.000 |

#### Observed settings

| Architecture | Config | shared_buffers | work_mem | effective_cache_size | max_wal_size | checkpoint_timeout |
| --- | --- | --- | --- | --- | --- | --- |
| amd64 | baseline-r1 | 128MB | 4MB | 4GB | 1GB | 5min |
| amd64 | baseline-r2 | 128MB | 4MB | 4GB | 1GB | 5min |
| amd64 | baseline-r3 | 128MB | 4MB | 4GB | 1GB | 5min |
| amd64 | postgis-buffers-r1 | 128MB | 4MB | 384MB | 256MB | 5min |
| amd64 | postgis-buffers-r2 | 128MB | 4MB | 384MB | 256MB | 5min |
| amd64 | postgis-buffers-r3 | 128MB | 4MB | 384MB | 256MB | 5min |
| amd64 | postgis-wal-r1 | 64MB | 4MB | 256MB | 128MB | 15min |
| amd64 | postgis-wal-r2 | 64MB | 4MB | 256MB | 128MB | 15min |
| amd64 | postgis-wal-r3 | 64MB | 4MB | 256MB | 128MB | 15min |
| arm64 | baseline-r1 | 128MB | 4MB | 4GB | 1GB | 5min |
| arm64 | baseline-r2 | 128MB | 4MB | 4GB | 1GB | 5min |
| arm64 | baseline-r3 | 128MB | 4MB | 4GB | 1GB | 5min |
| arm64 | postgis-buffers-r1 | 128MB | 4MB | 384MB | 256MB | 5min |
| arm64 | postgis-buffers-r2 | 128MB | 4MB | 384MB | 256MB | 5min |
| arm64 | postgis-buffers-r3 | 128MB | 4MB | 384MB | 256MB | 5min |
| arm64 | postgis-wal-r1 | 64MB | 4MB | 256MB | 128MB | 15min |
| arm64 | postgis-wal-r2 | 64MB | 4MB | 256MB | 128MB | 15min |
| arm64 | postgis-wal-r3 | 64MB | 4MB | 256MB | 128MB | 15min |

### Record caveats

No collection errors were recorded. This does not establish comparability beyond the stored metadata.
